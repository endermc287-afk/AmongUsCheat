package com.amongushile.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.amongushile.R;
import com.amongushile.cheat.CheatEngine;
import com.amongushile.service.FloatingMenuService;

/**
 * MainActivity
 * Uygulama başlatıldığında:
 *   1. SYSTEM_ALERT_WINDOW izni iste
 *   2. Among Us yüklü mü kontrol et
 *   3. Floating menu servisini başlat
 *   4. Oyunu başlat → kapat
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQ_OVERLAY = 100;
    private CheatEngine engine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        engine = CheatEngine.get(this);
        setupUI();
    }

    private void setupUI() {
        TextView tvStatus = findViewById(R.id.tv_status);
        Button   btnStart = findViewById(R.id.btn_start);

        boolean auInstalled = engine.isAuInstalled();
        tvStatus.setText(auInstalled
            ? "✓ Among Us tespit edildi"
            : "✗ Among Us bulunamadı — önce yükle");

        btnStart.setOnClickListener(v -> {
            if (!auInstalled) {
                toast("Among Us yüklü değil!");
                return;
            }
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
            } else {
                launchAll();
            }
        });
    }

    // ─── İzin ────────────────────────────────────────────────────────────────

    private void requestOverlayPermission() {
        Intent intent = new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getPackageName())
        );
        startActivityForResult(intent, REQ_OVERLAY);
        toast("'Diğer uygulamaların üzerinde göster' iznini aç, sonra geri dön");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                launchAll();
            } else {
                toast("İzin verilmedi — floating menu çalışmaz");
            }
        }
    }

    // ─── Başlat ───────────────────────────────────────────────────────────────

    private void launchAll() {
        // 1. Floating menu servisini başlat
        Intent svc = new Intent(this, FloatingMenuService.class);
        startForegroundService(svc);

        // 2. Among Us'u başlat
        Intent game = engine.getLaunchIntent();
        if (game != null) {
            game.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(game);
        }

        // 3. Bu activity'yi kapat (overlay aktif kalır)
        finish();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
