package com.amongushile.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import com.amongushile.R;
import com.amongushile.cheat.CheatEngine;

/**
 * FloatingMenuService
 * SYSTEM_ALERT_WINDOW izniyle ekranın üstünde çizer.
 * Her uygulamanın üzerinde kalır — Among Us açıkken de görünür.
 */
public class FloatingMenuService extends Service {

    private static final String CHANNEL_ID = "FLOAT_MENU";
    private static final int    NOTIF_ID   = 1337;

    private WindowManager   wm;
    private View            fabView;       // küçük yüzen buton (◈)
    private View            menuView;      // açılan panel
    private boolean         menuOpen = false;

    private CheatEngine engine;

    // Switch referansları
    private Switch swImpostor, swESP, swSpeed, swTasks, swKick, swKillAll;
    private TextView tvRole;
    private int roleIndex = 1; // default: Impostor

    @Override
    public void onCreate() {
        super.onCreate();
        engine = CheatEngine.get(this);
        engine.initRootShell();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForegroundNotif();
        inflateFab();
        inflateMenu();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ─── Foreground Notification ─────────────────────────────────────────────

    private void startForegroundNotif() {
        NotificationChannel ch = new NotificationChannel(
            CHANNEL_ID, "Floating Menu", NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
            .createNotificationChannel(ch);

        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Among Us Hile Aktif")
            .setContentText("Overlay çalışıyor")
            .setSmallIcon(android.R.drawable.star_on)
            .build();

        startForeground(NOTIF_ID, notif);
    }

    // ─── FAB — küçük yüzen tetikleyici ───────────────────────────────────────

    private void inflateFab() {
        fabView = LayoutInflater.from(this).inflate(R.layout.layout_fab, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 200;

        wm.addView(fabView, params);
        makeDraggable(fabView, params);

        fabView.setOnClickListener(v -> toggleMenu());
    }

    // ─── Menu Panel ───────────────────────────────────────────────────────────

    private void inflateMenu() {
        menuView = LayoutInflater.from(this).inflate(R.layout.layout_menu, null);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            dpToPx(280),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dpToPx(48);
        params.y = 200;

        menuView.setVisibility(View.GONE);
        wm.addView(menuView, params);

        bindMenuViews();
    }

    private void bindMenuViews() {
        // Switch'ler
        swImpostor = menuView.findViewById(R.id.sw_impostor);
        swESP      = menuView.findViewById(R.id.sw_esp);
        swSpeed    = menuView.findViewById(R.id.sw_speed);
        swTasks    = menuView.findViewById(R.id.sw_tasks);
        swKick     = menuView.findViewById(R.id.sw_kick);
        swKillAll  = menuView.findViewById(R.id.sw_kill_all);
        tvRole     = menuView.findViewById(R.id.tv_role_value);

        tvRole.setText(CheatEngine.ROLE_NAMES[roleIndex]);

        // Rol < buton
        menuView.findViewById(R.id.btn_role_prev).setOnClickListener(v -> {
            roleIndex = (roleIndex - 1 + CheatEngine.ROLE_NAMES.length)
                      % CheatEngine.ROLE_NAMES.length;
            tvRole.setText(CheatEngine.ROLE_NAMES[roleIndex]);
            runCheat(() -> engine.setRole(roleIndex));
        });

        // Rol > buton
        menuView.findViewById(R.id.btn_role_next).setOnClickListener(v -> {
            roleIndex = (roleIndex + 1) % CheatEngine.ROLE_NAMES.length;
            tvRole.setText(CheatEngine.ROLE_NAMES[roleIndex]);
            runCheat(() -> engine.setRole(roleIndex));
        });

        // Always Impostor
        swImpostor.setOnCheckedChangeListener((b, on) -> {
            CheatEngine.alwaysImpostor = on;
            if (on) runCheat(() -> engine.applyAlwaysImpostor());
        });

        // Player ESP
        swESP.setOnCheckedChangeListener((b, on) -> {
            CheatEngine.playerESP = on;
            if (on) runCheat(() -> engine.applyPlayerESP());
        });

        // Speed Hack
        swSpeed.setOnCheckedChangeListener((b, on) -> {
            CheatEngine.speedHack = on;
            if (on) runCheat(() -> engine.applySpeedHack(3.0f));
            else    runCheat(() -> engine.applySpeedHack(1.0f));
        });

        // Complete All Tasks
        swTasks.setOnCheckedChangeListener((b, on) -> {
            CheatEngine.completeAllTasks = on;
            if (on) runCheat(() -> engine.applyCompleteAllTasks());
        });

        // Kick All
        swKick.setOnCheckedChangeListener((b, on) -> {
            CheatEngine.kickAll = on;
            if (on) runCheat(() -> engine.applyKickAll());
        });

        // Kill All
        swKillAll.setOnCheckedChangeListener((b, on) -> {
            CheatEngine.killAll = on;
            if (on) runCheat(() -> engine.applyKillAll());
        });

        // Launch Game butonu
        menuView.findViewById(R.id.btn_launch).setOnClickListener(v -> {
            Intent launch = engine.getLaunchIntent();
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                // oyun açılınca process bul
                new android.os.Handler().postDelayed(() ->
                    runCheat(() -> { engine.findProcess(); return engine.findLibBase(); }),
                3000);
            } else {
                toast("Among Us yüklü değil!");
            }
        });

        // Kapat butonu
        menuView.findViewById(R.id.btn_close).setOnClickListener(v -> toggleMenu());
    }

    // ─── Toggle ───────────────────────────────────────────────────────────────

    private void toggleMenu() {
        menuOpen = !menuOpen;
        menuView.setVisibility(menuOpen ? View.VISIBLE : View.GONE);
    }

    // ─── Draggable FAB ───────────────────────────────────────────────────────

    private void makeDraggable(View view, WindowManager.LayoutParams params) {
        final float[] lastX = {0}, lastY = {0};
        final boolean[] moved = {false};

        view.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    lastX[0] = e.getRawX();
                    lastY[0] = e.getRawY();
                    moved[0] = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = e.getRawX() - lastX[0];
                    float dy = e.getRawY() - lastY[0];
                    if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                        params.x += (int) dx;
                        params.y += (int) dy;
                        wm.updateViewLayout(view, params);
                        lastX[0] = e.getRawX();
                        lastY[0] = e.getRawY();
                        moved[0] = true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) v.performClick();
                    return true;
            }
            return false;
        });
    }

    // ─── Yardımcılar ─────────────────────────────────────────────────────────

    interface CheatTask { boolean run(); }

    private void runCheat(CheatTask task) {
        new Thread(() -> {
            boolean ok = task.run();
            new android.os.Handler(getMainLooper())
                .post(() -> toast(ok ? "✓ Uygulandı" : "✗ Hata — oyun açık mı? Root var mı?"));
        }).start();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (fabView  != null) wm.removeView(fabView);
        if (menuView != null) wm.removeView(menuView);
    }
}
