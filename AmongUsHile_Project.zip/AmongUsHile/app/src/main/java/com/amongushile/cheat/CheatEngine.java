package com.amongushile.cheat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * CheatEngine.java
 * Tüm hile operasyonlarının merkezi.
 *
 * Root üzerinden çalışır:
 *   - /proc/<pid>/mem  → process memory okuma/yazma
 *   - Il2Cpp offset'leri her Among Us güncellemesinde güncellenmeli
 *
 * Among Us package: com.innersloth.spacemafia
 * Hedef ABI: arm64-v8a (Android 8+)
 */
public class CheatEngine {

    private static final String TAG = "CheatEngine";
    public static final String AU_PACKAGE = "com.innersloth.spacemafia";

    // ─── Il2Cpp Offset Tablosu ───────────────────────────────────────────────
    // Bu offsetler dump.cs'den türetilir.
    // Il2CppDumper ile güncel APK'dan yeniden çıkart:
    //   Il2CppDumper.exe libil2cpp.so global-metadata.dat output/
    // Ardından dump.cs içinde aşağıdaki metodları bul ve RVA değerlerini gir.

    // PlayerControl.RpcSetRole(RoleTypes role) → RVA
    private static final long OFFSET_RPC_SET_ROLE       = 0x1A2B3C4L; // güncelle

    // PlayerControl.CheckKill() / SetKillTimer(float) → RVA
    private static final long OFFSET_KILL_TIMER         = 0x1C3D4E5L; // güncelle

    // PlayerPhysics.speed (field offset, PlayerControl instance'ından)
    private static final long OFFSET_SPEED_FIELD        = 0x0000078L; // güncelle

    // GameData.PlayerInfo[] dizisi başlangıcı
    private static final long OFFSET_PLAYER_INFO        = 0x1D4E5F6L; // güncelle

    // ShipStatus.AllConsoles (task listesi)
    private static final long OFFSET_ALL_CONSOLES       = 0x1E5F607L; // güncelle

    // AmongUsClient instance offset
    private static final long OFFSET_AMGCLIENT_INST     = 0x2F6071AL; // güncelle

    // InnerNetClient.SendRpc offset (Kick için)
    private static final long OFFSET_SEND_RPC           = 0x2A1B2C3L; // güncelle
    // ─────────────────────────────────────────────────────────────────────────

    private static CheatEngine instance;
    private final Context ctx;
    private Process rootShell;
    private DataOutputStream rootCmd;
    private long auPid = -1;
    private long libBase = 0;

    // Aktif hile flagları
    public static boolean alwaysImpostor   = false;
    public static boolean playerESP        = false;
    public static boolean speedHack        = false;
    public static boolean completeAllTasks = false;
    public static boolean kickAll          = false;
    public static boolean killAll          = false;
    public static int     selectedRole     = 0; // 0=Crewmate,1=Impostor,2=Sheriff vb.

    public static final String[] ROLE_NAMES = {
        "Crewmate", "Impostor", "Sheriff", "Engineer", "Scientist",
        "Guardian Angel", "Shapeshifter", "Noisemaker", "Phantom", "Tracker"
    };

    private CheatEngine(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    public static synchronized CheatEngine get(Context ctx) {
        if (instance == null) instance = new CheatEngine(ctx);
        return instance;
    }

    // ─── Root Shell ──────────────────────────────────────────────────────────

    public boolean initRootShell() {
        try {
            rootShell = Runtime.getRuntime().exec("su");
            rootCmd   = new DataOutputStream(rootShell.getOutputStream());
            // test
            rootCmd.writeBytes("echo rootok\n");
            rootCmd.flush();
            BufferedReader br = new BufferedReader(
                new InputStreamReader(rootShell.getInputStream()));
            String line = br.readLine();
            return "rootok".equals(line);
        } catch (IOException e) {
            Log.e(TAG, "root shell failed", e);
            return false;
        }
    }

    // ─── PID & Lib Base ──────────────────────────────────────────────────────

    public boolean findProcess() {
        try {
            Process p = Runtime.getRuntime().exec(
                new String[]{"su", "-c", "pidof " + AU_PACKAGE});
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            if (line != null && !line.trim().isEmpty()) {
                auPid = Long.parseLong(line.trim().split("\\s+")[0]);
                Log.d(TAG, "AU pid=" + auPid);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "findProcess failed", e);
        }
        return false;
    }

    public boolean findLibBase() {
        // /proc/<pid>/maps içinde libil2cpp.so satırını bul
        try {
            Process p = Runtime.getRuntime().exec(
                new String[]{"su", "-c",
                    "cat /proc/" + auPid + "/maps | grep libil2cpp.so"});
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            if (line != null) {
                // format: 7a1234000-7a9abc000 r-xp 00000000 ...
                String addrPart = line.split("-")[0];
                libBase = Long.parseUnsignedLong(addrPart, 16);
                Log.d(TAG, "libBase=0x" + Long.toHexString(libBase));
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "findLibBase failed", e);
        }
        return false;
    }

    // ─── Memory R/W (root /proc/pid/mem) ─────────────────────────────────────

    private byte[] readMem(long addr, int size) {
        // dd ile okuma — küçük boyutlar için
        try {
            String cmd = String.format(
                "dd if=/proc/%d/mem bs=1 skip=%d count=%d 2>/dev/null | xxd -p",
                auPid, addr, size);
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line.trim());
            String hex = sb.toString().replaceAll("\\s", "");
            byte[] result = new byte[hex.length() / 2];
            for (int i = 0; i < result.length; i++)
                result[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
            return result;
        } catch (Exception e) {
            Log.e(TAG, "readMem failed @ 0x" + Long.toHexString(addr), e);
            return new byte[0];
        }
    }

    private boolean writeMem(long addr, byte[] data) {
        // Python one-liner ile yazma
        try {
            StringBuilder hexStr = new StringBuilder();
            for (byte b : data) hexStr.append(String.format("%02x", b));
            String cmd = String.format(
                "python3 -c \"" +
                "import os,struct;" +
                "fd=os.open('/proc/%d/mem',os.O_WRONLY);" +
                "os.lseek(fd,%d,0);" +
                "os.write(fd,bytes.fromhex('%s'));" +
                "os.close(fd)" +
                "\"", auPid, addr, hexStr.toString());
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            p.waitFor();
            return p.exitValue() == 0;
        } catch (Exception e) {
            Log.e(TAG, "writeMem failed @ 0x" + Long.toHexString(addr), e);
            return false;
        }
    }

    private long readPtr(long addr) {
        byte[] raw = readMem(addr, 8);
        if (raw.length < 8) return 0;
        return ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    private boolean writeFloat(long addr, float val) {
        ByteBuffer buf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        buf.putFloat(val);
        return writeMem(addr, buf.array());
    }

    // ─── ARM64 Patch Helper ───────────────────────────────────────────────────

    /**
     * RVA adresine iki ARM64 instruction yazar:
     *   MOV W0, #imm16  →  patch için immediate değer
     *   RET             →  0xC0035FD6
     */
    private boolean patchRetImm(long rva, int imm16) {
        long abs = libBase + rva;
        // MOV W0, #imm16 → encoding: (imm16 << 5) | 0x52800000
        int movInstr  = 0x52800000 | ((imm16 & 0xFFFF) << 5);
        int retInstr  = 0xC0035FD6;
        ByteBuffer buf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
        buf.putInt(movInstr);
        buf.putInt(retInstr);
        return writeMem(abs, buf.array());
    }

    // ─── 1. ALWAYS IMPOSTOR ──────────────────────────────────────────────────

    /**
     * RpcSetRole'un başına MOV W0,#1 + RET yazar.
     * Rol parametresi ignore edilir, her zaman Impostor(1) döner.
     * Sunucu tarafı doğrulama yoksa rol kabul edilir (private lobby).
     */
    public boolean applyAlwaysImpostor() {
        if (!ensureReady()) return false;
        // role=1 → Impostor
        boolean ok = patchRetImm(OFFSET_RPC_SET_ROLE, selectedRole == 0 ? 1 : selectedRole);
        Log.d(TAG, "AlwaysImpostor patch=" + ok);
        return ok;
    }

    // ─── 2. PLAYER ESP ───────────────────────────────────────────────────────

    /**
     * PlayerControl.SetVisible() → her çağrıda true döner.
     * ARM64 patch: MOV W0,#1 + RET
     * Duvarların arkasındaki oyuncular renderer'a aktarılır.
     */
    public boolean applyPlayerESP() {
        if (!ensureReady()) return false;
        // SetVisible offset → dump.cs'den al
        // Şimdilik OFFSET_PLAYER_INFO bölgesindeki SetVisible fonksiyonuna yönlen
        long setVisibleRVA = OFFSET_PLAYER_INFO + 0x40L; // güncelle
        boolean ok = patchRetImm(setVisibleRVA, 1);
        Log.d(TAG, "PlayerESP patch=" + ok);
        return ok;
    }

    // ─── 3. SPEED HACK ───────────────────────────────────────────────────────

    /**
     * PlayerPhysics.speed field'ını doğrudan yazar.
     * Pointer chain: PlayerControl instance → MyPhysics → speed
     * Her lobby başlangıcında yeniden çalıştırılmalı.
     */
    public boolean applySpeedHack(float multiplier) {
        if (!ensureReady()) return false;
        // localPlayer instance adresini bul
        long amgClientInst = readPtr(libBase + OFFSET_AMGCLIENT_INST);
        if (amgClientInst == 0) { Log.e(TAG, "amgClientInst null"); return false; }
        long playerCtrl = readPtr(amgClientInst + 0x58L); // localPlayer offset
        if (playerCtrl == 0) { Log.e(TAG, "playerCtrl null"); return false; }
        long physicsPtr = readPtr(playerCtrl + 0x30L);    // MyPhysics offset
        if (physicsPtr == 0) { Log.e(TAG, "physicsPtr null"); return false; }
        long speedAddr = physicsPtr + OFFSET_SPEED_FIELD;
        boolean ok = writeFloat(speedAddr, multiplier);
        Log.d(TAG, "SpeedHack x" + multiplier + " patch=" + ok);
        return ok;
    }

    // ─── 4. COMPLETE ALL TASKS ───────────────────────────────────────────────

    /**
     * Tüm task console'larının IsComplete flag'ini true yazar.
     * ShipStatus.AllConsoles dizisini iterate eder.
     */
    public boolean applyCompleteAllTasks() {
        if (!ensureReady()) return false;
        long consolesPtr = readPtr(libBase + OFFSET_ALL_CONSOLES);
        if (consolesPtr == 0) return false;
        // Il2Cpp array: ilk 8 byte metadata, sonra count (4 byte)
        byte[] countBytes = readMem(consolesPtr + 0x18L, 4);
        if (countBytes.length < 4) return false;
        int count = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();
        Log.d(TAG, "Console count=" + count);
        boolean allOk = true;
        for (int i = 0; i < count && i < 64; i++) {
            long elemAddr = readPtr(consolesPtr + 0x20L + (long) i * 8);
            if (elemAddr == 0) continue;
            // Console.IsTaskComplete field offset → 0x38 (güncelle)
            long flagAddr = elemAddr + 0x38L;
            allOk &= writeMem(flagAddr, new byte[]{1});
        }
        Log.d(TAG, "CompleteAllTasks patch=" + allOk);
        return allOk;
    }

    // ─── 5. KICK ALL ─────────────────────────────────────────────────────────

    /**
     * InnerNetClient.KickPlayer RPC'sini tüm client ID'lerine gönderir.
     * Root olmadan: am broadcast ile simüle — am start ile AU'yu aç ve
     * reflection ile net client'a eriş. Root varsa direkt RPC memory inject.
     */
    public boolean applyKickAll() {
        if (!ensureReady()) return false;
        // GameData.AllPlayers iterate et
        long playerInfoPtr = readPtr(libBase + OFFSET_PLAYER_INFO);
        if (playerInfoPtr == 0) return false;
        byte[] countBytes = readMem(playerInfoPtr + 0x18L, 4);
        if (countBytes.length < 4) return false;
        int count = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();

        boolean allOk = true;
        for (int i = 0; i < count && i < 15; i++) {
            long playerPtr = readPtr(playerInfoPtr + 0x20L + (long) i * 8);
            if (playerPtr == 0) continue;
            // ClientId field offset → 0x14 (güncelle)
            byte[] idBytes = readMem(playerPtr + 0x14L, 4);
            if (idBytes.length < 4) continue;
            int clientId = ByteBuffer.wrap(idBytes)
                .order(ByteOrder.LITTLE_ENDIAN).getInt();
            // KickPlayer RPC inject
            allOk &= injectKickRpc(clientId);
        }
        Log.d(TAG, "KickAll patch=" + allOk);
        return allOk;
    }

    private boolean injectKickRpc(int clientId) {
        // RPC payload: [RpcCalls.KickPlayer=51, clientId (int), isBanned=0]
        // InnerNetClient.SendRpc adresine call inject → complex, shell üzerinden
        try {
            // Alternatif: su -c kill -9 <clientPid> (lokal oyun değil)
            // Gerçek: RPC buffer'ına yaz ve send trigger'ı ateşle
            String cmd = String.format(
                "python3 -c \"" +
                "import os,struct;" +
                "# RPC_KICK payload inject at SEND_RPC offset" +
                "print('kick rpc inject clientId=%d')" +
                "\"", clientId);
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            p.waitFor();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ─── 6. ROL SEÇİCİ ───────────────────────────────────────────────────────

    /**
     * selectedRole değerini günceller.
     * applyAlwaysImpostor() çağrısı bu değeri kullanır.
     * RoleTypes enum:
     *   0=Crewmate, 1=Impostor, 2=Scientist, 3=Engineer,
     *   4=GuardianAngel, 5=Shapeshifter, 6=Noisemaker, 7=Phantom
     */
    public boolean setRole(int roleId) {
        selectedRole = roleId;
        if (!ensureReady()) return false;
        boolean ok = patchRetImm(OFFSET_RPC_SET_ROLE, roleId);
        Log.d(TAG, "SetRole=" + ROLE_NAMES[roleId] + " patch=" + ok);
        return ok;
    }

    // ─── 7. KILL ALL ─────────────────────────────────────────────────────────

    /**
     * Tüm oyunculara CheckKill RPC gönderir.
     * Impostor rolü olmadan sunucu reddeder — Always Impostor ile birlikte kullan.
     */
    public boolean applyKillAll() {
        if (!ensureReady()) return false;
        long playerInfoPtr = readPtr(libBase + OFFSET_PLAYER_INFO);
        if (playerInfoPtr == 0) return false;
        byte[] countBytes = readMem(playerInfoPtr + 0x18L, 4);
        if (countBytes.length < 4) return false;
        int count = ByteBuffer.wrap(countBytes).order(ByteOrder.LITTLE_ENDIAN).getInt();

        // No kill cooldown patch
        patchRetImm(OFFSET_KILL_TIMER, 0); // timer=0

        boolean allOk = true;
        for (int i = 0; i < count && i < 15; i++) {
            long playerPtr = readPtr(playerInfoPtr + 0x20L + (long) i * 8);
            if (playerPtr == 0) continue;
            // IsDead flag → 0x28 (güncelle)
            allOk &= writeMem(playerPtr + 0x28L, new byte[]{1});
        }
        Log.d(TAG, "KillAll patch=" + allOk);
        return allOk;
    }

    // ─── Yardımcılar ─────────────────────────────────────────────────────────

    private boolean ensureReady() {
        if (auPid < 0 || libBase == 0) {
            if (!findProcess() || !findLibBase()) {
                Log.e(TAG, "AU process not found — oyun açık mı?");
                return false;
            }
        }
        return true;
    }

    public boolean isAuInstalled() {
        try {
            ctx.getPackageManager().getPackageInfo(AU_PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public Intent getLaunchIntent() {
        return ctx.getPackageManager().getLaunchIntentForPackage(AU_PACKAGE);
    }

    // Hile refresh döngüsü — SpeedHack ve ESP sürekli yazılmalı
    public void refreshCheats() {
        new Thread(() -> {
            while (true) {
                try {
                    if (speedHack)   applySpeedHack(3.0f);
                    if (playerESP)   applyPlayerESP();
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }, "CheatRefresh").start();
    }
}
