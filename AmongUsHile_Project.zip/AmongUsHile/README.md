# Among Us Hile — Android Floating Menu
**made by lowkeyy**

---

## Özellikler
| Özellik | Mekanizma |
|---|---|
| Always Impostor | RpcSetRole patch — her zaman seçilen rolü döner |
| Player ESP | SetVisible patch — duvar arkası görünür |
| Speed Hack ×3 | PlayerPhysics.speed field yazma |
| Complete All Tasks | Console.IsComplete flag override |
| Kick All | KickPlayer RPC inject |
| Rol Seçici | RpcSetRole parametresi (Crewmate→Phantom) |
| Kill All | PlayerInfo.IsDead flag + kill timer sıfırlama |

---

## Gereksinimler
- **Root** (Magisk / KernelSU)  
- Android 8.0+ (API 26+)  
- Among Us yüklü (`com.innersloth.spacemafia`)  
- Python 3 (memory write için — `/proc/pid/mem`)

---

## Build

```bash
# Android Studio'da aç veya:
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

# Install
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Offset Güncelleme (Her AU Güncellemesinde Zorunlu)

```bash
# 1. AU APK'yı çıkart
adb pull /data/app/com.innersloth.spacemafia*/base.apk au.apk
apktool d au.apk -o au_out

# 2. libil2cpp.so + global-metadata.dat
# au_out/lib/arm64-v8a/libil2cpp.so
# au_out/assets/bin/Data/Managed/Metadata/global-metadata.dat

# 3. Il2CppDumper çalıştır
Il2CppDumper.exe libil2cpp.so global-metadata.dat output/

# 4. dump.cs içinde ara:
grep -n "RpcSetRole\|CheckKill\|SetKillTimer\|SetVisible\|IsComplete" output/dump.cs

# 5. RVA değerlerini CheatEngine.java'ya yaz:
#    OFFSET_RPC_SET_ROLE   = dump.cs'deki RVA
#    OFFSET_KILL_TIMER     = dump.cs'deki RVA
#    vb.
```

---

## Kullanım

1. APK kur → `AU Hile` aç  
2. "Diğer uygulamaların üzerinde göster" izni ver  
3. **OYUNU BAŞLAT** → Among Us açılır, hile menüsü ◈ ekranda  
4. ◈ butonuna dokun → panel açılır  
5. İstediğin hileleri switch ile aç  
6. Rol Seçici: ◀ ▶ ile rol seç → Always Impostor ile birlikte çalışır  

---

## Notlar

```
- Private lobby: tüm özellikler çalışır
- Public lobby: sunucu tarafı doğrulama bazı özellikleri engeller
- Her AU güncellemesinde offset re-derive zorunlu
- arm64-v8a hedef — ARMv7 cihazlar için encoding aynı mantık
- Kick All / Kill All: lobyde host olmasan da çalışabilir (AU RPC doğrulaması zayıf)
```

---

## Proje Yapısı

```
AmongUsHile/
├── app/src/main/
│   ├── java/com/amongushile/
│   │   ├── cheat/CheatEngine.java     ← tüm hile mantığı + memory R/W
│   │   ├── service/FloatingMenuService.java  ← overlay + UI
│   │   └── ui/MainActivity.java       ← izin + başlatıcı
│   └── res/layout/
│       ├── activity_main.xml
│       ├── layout_fab.xml             ← ◈ yüzen buton
│       └── layout_menu.xml            ← panel
└── README.md
```
